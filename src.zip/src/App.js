import logo from './logo.svg';
import './App.css';
import { useEffect } from 'react'
import { useDispatch } from 'react-redux';
import { handleInitialData } from './service/service'



function App() {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(handleInitialData());
  }, []);


  return (
    <ul>
      <li>
        <input id="c1" type="checkbox" />
        <label for="c1">Checkbox</label>
      </li>
      <li>
        <label for="name" className="p">
          <input type="text" id="name" placeholder="Name" />
          <span>Name</span>
        
        </label>
        <div className="done">&#x2713;</div>
      </li>
    </ul>
  );
}

export default App;