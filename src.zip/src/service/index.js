import { combineReducers } from 'redux';
import countries from './countries';

export default combineReducers({
  countries
});